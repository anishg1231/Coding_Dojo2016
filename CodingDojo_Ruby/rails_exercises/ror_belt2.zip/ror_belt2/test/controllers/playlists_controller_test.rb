require 'test_helper'

class PlaylistsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
