require 'test_helper'

class PlaylistsHelperTest < ActionView::TestCase
end
