var mathlib = require('./mathlib');
mathlib.add(5,6);
mathlib.multiply(5,6);
mathlib.square(5,2);
mathlib.random(1,35);
